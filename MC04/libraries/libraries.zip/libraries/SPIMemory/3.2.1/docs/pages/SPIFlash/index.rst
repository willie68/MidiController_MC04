.. _Usage:

##############
API and Usage
##############

.. toctree::
   :hidden:
   :maxdepth: 1
   :caption: Structure

   libStructure.rst

.. toctree::
   :maxdepth: 1
   :caption: Contents

   constructor.rst

.. toctree::
   :maxdepth: 2

   libInstantiate.rst
   chipID.rst
   readFunc.rst
   writeFunc.rst
