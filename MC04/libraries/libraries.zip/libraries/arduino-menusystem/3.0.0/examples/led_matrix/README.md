This example depends on the arduino-ht1632c library which can be found at
https://github.com/jonblack/ht1632c. This is a fork of
https://github.com/wildstray/ht1632c with some fixes applied.
