# RCReceiver
An arduino library for comunicate with a rc receiver
This library can read and decode PPM signals from simple RC receivers. On Arduino Uno there are 2 channels supported, on others like leonardo or mega, 4 channels. 
